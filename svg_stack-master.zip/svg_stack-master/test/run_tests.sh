#!/bin/bash
set -e
python test1.py
python test2.py
python test3.py
python test4.py
python test5.py
echo 'OK'
